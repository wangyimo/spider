from urllib import request
import re
class Spider():
    #电子书网址
    url = 'http://d81fb43e-d.parkone.cn'
    
    #所有书
    root_pattern = '<div class="cover">([\s\S]*?)</div>'
    #所有书详情
    root_pattern1 = '<a href="([\s\S]*?)" data-toggle="modal" data-target="#bookDetailsModal" data-remote="false">'
    #书名
    book_pattern = '<h2>([\s\S]*?)</h2>'
    #作者
    author_pattern = '<a href="/author/[\s\S]*?">([\s\S]*?)</a>'
    #出版社
    press_pattern = '<span>出版社:([\s\S]*?)</span>'
    #出版日期
    date_pattern = '<p>出版日期:([\s\S]*?)</p>'
    #简介
    brief_pattern = '<p class="description">([\s\S]*?)</p>'


    def __fetch_content(self,url):
        resp = request.urlopen(url)
        htmls = resp.read()
        htmls = str(htmls,encoding='utf-8')
        return htmls 

    #找到书籍链接
    def find_book(self,htmls):
        book_url = re.findall(Spider.root_pattern,htmls)
        book_urls = []
        for i in book_url:
            book_url = re.findall(Spider.root_pattern1,i)
            new_url = Spider.url + book_url[0]
            book_urls.append(new_url)
        return book_urls

    #爬书方法
    def __analysis(self,htmls):
        anchors = []
        book = re.findall(Spider.book_pattern,htmls)
        author = re.findall(Spider.author_pattern,htmls)
        press = re.findall(Spider.press_pattern,htmls)
        date = re.findall(Spider.date_pattern,htmls)
        brief = re.findall(Spider.brief_pattern,htmls)
        anchor = {'书名':book,'作者':author,'出版社':press,'出版日期':date,'内容简介':brief}
        anchors.append(anchor)
        return anchors
        
    def show(self,anchors):
        for i in anchors:
            print('书名'+str(i['书名']))
            print('作者'+str(i['作者']))
            print('出版社'+str(i['出版社']))
            print('出版日期'+str(i['出版日期']))
            print('内容简介'+str(i['内容简介']))
            print('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')

    

    def go(self):
        i = 1
        while True:
            #分页网址
            page_url = 'http://d81fb43e-d.parkone.cn/page/{}'.format(str(i))
            htmls = self.__fetch_content(page_url)
            book_urls = self.find_book(htmls)
            if len(book_urls) != 0:
                for url in book_urls:
                    html = self.__fetch_content(url)
                    anchors = self.__analysis(html)
                    self.show(anchors)
                i += 1
            else:
                break
sp = Spider()
sp.go()